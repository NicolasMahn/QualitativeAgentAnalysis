import pickle 
import os
os.makedirs('output', exist_ok=True)



import dash
from dash import html, dcc
import pandas as pd
import plotly.express as px

# 1. Read and preprocess
df = pd.read_csv("uploads/Employee.csv")

# Correct spelling in dataset: use "PHD"
levels = ["Other", "Bachelors", "Masters", "PHD"]
df["Education"] = df["Education"].where(df["Education"].isin(levels), "Other")
df["Education"] = pd.Categorical(df["Education"], categories=levels, ordered=True)

# 2. Compute summary stats
summary = df.groupby("Education")["PaymentTier"].agg(
    Average="mean",
    Median="median",
    Count="count"
).reset_index()

# 3. Create figures
fig_box = px.box(
    df,
    x="Education",
    y="PaymentTier",
    title="Distribution of PaymentTier by Education Level",
    points="all"
)

fig_bar = px.bar(
    summary.melt(id_vars="Education", value_vars=["Average","Median"]),
    x="Education", y="value", color="variable",
    barmode="group",
    title="Average & Median PaymentTier by Education Level",
    labels={"value":"PaymentTier","variable":"Statistic"}
)

# 4. Helper to generate HTML table
def generate_table(dataframe, max_rows=10):
    header = [html.Th(col) for col in dataframe.columns]
    rows = []
    for i in range(min(len(dataframe), max_rows)):
        rows.append(html.Tr([html.Td(dataframe.iloc[i][col]) for col in dataframe.columns]))
    return html.Table([html.Tr(header)] + rows)

# 5. Build Dash app
app = dash.Dash(__name__)
app.layout = html.Div([
    html.H1("Education vs Payment Tier Analysis"),
    html.P("Assumptions: Education ordered as Other < Bachelors < Masters < PHD"),
    dcc.Graph(figure=fig_box),
    dcc.Graph(figure=fig_bar),
    html.H3("Summary Statistics (first 10 rows)"),
    generate_table(summary)
])

if __name__ == "__main__":
    app.run_server(debug=True)



import pickle 
import os
os.makedirs('output', exist_ok=True)



import dash
from dash import dcc, html, Input, Output
import plotly.express as px
import pandas as pd
from scipy import stats

# Load data
df = pd.read_csv("uploads/Employee.csv")

# Create experience groups
df['ExperienceGroup'] = pd.cut(df['ExperienceInCurrentDomain'],
                              bins=[-1, 2, 5, 15],
                              labels=['0-2', '3-5', '5+'])

app = dash.Dash(__name__)

app.layout = html.Div([
    html.H1("Employee Analytics Dashboard", style={'textAlign': 'center'}),
    
    # Experience Analysis Section
    html.Div([
        html.H2("Experience vs Payment Tier"),
        dcc.Graph(id='experience-payment-plot'),
        html.Div(id='correlation-output')
    ], style={'margin': '20px'}),
    
    # Education Analysis Section
    html.Div([
        html.H2("Education Analysis"),
        dcc.Dropdown(
            id='experience-filter',
            options=[{'label': grp, 'value': grp} for grp in ['All', '0-2', '3-5', '5+']],
            value='All',
            style={'width': '50%', 'margin': '10px'}
        ),
        dcc.Graph(id='education-payment-plot')
    ], style={'margin': '20px'})
])

# Experience Callback
@app.callback(
    [Output('experience-payment-plot', 'figure'),
     Output('correlation-output', 'children')],
    [Input('experience-payment-plot', 'relayoutData')]
)
def update_experience_analysis(_):
    # Box plot
    fig1 = px.box(df, x='PaymentTier', y='ExperienceInCurrentDomain',
                 title="Experience Distribution by Payment Tier",
                 labels={'PaymentTier': 'Payment Tier', 
                        'ExperienceInCurrentDomain': 'Years Experience'})
    
    # Correlation calculation
    corr = stats.spearmanr(df['PaymentTier'], df['ExperienceInCurrentDomain']).correlation
    stats_text = f"Spearman Correlation: {corr:.2f}"
    
    return fig1, stats_text

# Education Callback
@app.callback(
    Output('education-payment-plot', 'figure'),
    [Input('experience-filter', 'value')]
)
def update_education_analysis(selected_group):
    filtered_df = df if selected_group == 'All' else df[df['ExperienceGroup'] == selected_group]
    
    return px.histogram(filtered_df, x='Education', color='PaymentTier',
                      category_orders={'Education': ['Bachelors', 'Masters', 'PHD']},
                      title=f"Education vs Payment Tier {'('+selected_group+')' if selected_group != 'All' else ''}",
                      barmode='group')

if __name__ == '__main__':
    app.run_server(debug=True)



import pickle 
import os
os.makedirs('output', exist_ok=True)



import pandas as pd
import plotly.express as px
from dash import Dash, html, dcc

# Load data safely
try:
    df = pd.read_csv("uploads/Employee.csv")
    print("Data loaded successfully. Columns:", df.columns.tolist())
except Exception as e:
    print("Error loading data:", str(e))
    raise

# 1. Process gender distribution
gender_counts = df['Gender'].value_counts().reset_index()
gender_counts.columns = ['Gender', 'Count']

# Create pie chart with error handling
try:
    pie_fig = px.pie(gender_counts, 
                     values='Count', 
                     names='Gender',
                     title='Gender Distribution',
                     color_discrete_sequence=px.colors.qualitative.Pastel)
    print("Pie chart created successfully")
except Exception as e:
    print("Error creating pie chart:", str(e))
    raise

# 2. Process city-gender distribution
try:
    city_gender = pd.crosstab(df['City'], df['Gender']).reset_index()
    print("City-gender data processed successfully")
    
    bar_fig = px.bar(city_gender,
                     x='City',
                     y=['Female', 'Male'],
                     title='Gender Distribution by City',
                     labels={'value': 'Employees', 'variable': 'Gender'},
                     barmode='group',
                     color_discrete_sequence=px.colors.qualitative.Pastel)
except Exception as e:
    print("Error creating bar chart:", str(e))
    raise

# Build Dash app
try:
    app = Dash(__name__)
    
    app.layout = html.Div([
        html.H1("Employee Gender Analysis Dashboard", 
                style={'textAlign': 'center', 'padding': '20px'}),
        
        html.Div([
            dcc.Graph(figure=pie_fig)
        ], style={'width': '48%', 'display': 'inline-block', 'padding': '10px'}),
        
        html.Div([
            dcc.Graph(figure=bar_fig)
        ], style={'width': '48%', 'display': 'inline-block', 'padding': '10px'})
    ])
    
    print("Dash app layout created successfully")
except Exception as e:
    print("Error creating Dash app:", str(e))
    raise

if __name__ == '__main__':
    app.run_server(debug=True)



import pickle 
import os
os.makedirs('output', exist_ok=True)



import dash
from dash import dcc, html
import plotly.express as px
import pandas as pd

# Load and prepare data
df = pd.read_csv("uploads/Employee.csv")
education_order = ['Bachelors', 'Masters', 'PHD']

# Initialize Dash app
app = dash.Dash(__name__)

app.layout = html.Div([
    html.H1("Employee Education vs Payment Tier Analysis"),
    
    dcc.Dropdown(
        id='chart-selector',
        options=[
            {'label': 'Box Plot', 'value': 'box'},
            {'label': 'Bar Chart', 'value': 'bar'}
        ],
        value='box',
        style={'width': '50%'}
    ),
    
    dcc.Graph(id='education-payment-plot')
])

@app.callback(
    dash.dependencies.Output('education-payment-plot', 'figure'),
    [dash.dependencies.Input('chart-selector', 'value')]
)
def update_graph(selected_chart):
    if selected_chart == 'box':
        fig = px.box(df, x='Education', y='PaymentTier', 
                    category_orders={"Education": education_order},
                    title="Payment Tier Distribution by Education")
    else:
        agg_data = df.groupby('Education', as_index=False)['PaymentTier'].median()
        fig = px.bar(agg_data, x='Education', y='PaymentTier',
                    category_orders={"Education": education_order},
                    title="Median Payment Tier by Education")
    
    fig.update_layout(transition_duration=500)
    return fig

if __name__ == '__main__':
    app.run_server(debug=True)



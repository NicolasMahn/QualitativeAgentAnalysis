import pickle 
import os
os.makedirs('output', exist_ok=True)



import pandas as pd
import numpy as np
import plotly.express as px
from dash import Dash, html, dcc

# Load dataset
df = pd.read_csv('uploads/Employee.csv')

# Define categorization function for education levels
def categorize_education(edu):
    edu = str(edu).lower()
    if 'phd' in edu or 'doctorate' in edu:
        return 'PhD'
    elif 'master' in edu:
        return 'Masters'
    elif 'bachelor' in edu:
        return 'Bachelors'
    else:
        return 'Others'

# Create new simplified education level column
df['EducationLevel'] = df['Education'].apply(categorize_education)

# Define ordered categories for plotting
edu_order = ['Others', 'Bachelors', 'Masters', 'PhD']
df['EducationLevel'] = pd.Categorical(df['EducationLevel'], categories=edu_order, ordered=True)

# Create summary statistics for average and median PaymentTier per education level
summary_df = df.groupby('EducationLevel')['PaymentTier'].agg(['mean', 'median']).reset_index()

# Initialize Dash app
app = Dash(__name__)

app.layout = html.Div([
    html.H1("Employee Education vs Payment Tier Analysis", style={'textAlign': 'center'}),

    html.Div([
        html.H2("Distribution of Payment Tiers per Education Level"),
        dcc.Graph(
            id='box-plot',
            figure=px.box(df, x='EducationLevel', y='PaymentTier',
                          category_orders={'EducationLevel': edu_order},
                          points='all',
                          labels={'EducationLevel': 'Education Level', 'PaymentTier': 'Payment Tier'},
                          title='Boxplot of Payment Tier by Education Level')
        )
    ], style={'width': '50%', 'display': 'inline-block', 'padding': '0 20'}),

    html.Div([
        html.H2("Average and Median Payment Tier per Education Level"),
        dcc.Graph(
            id='bar-chart',
            figure=px.bar(summary_df, x='EducationLevel', y=['mean', 'median'],
                          category_orders={'EducationLevel': edu_order},
                          labels={'value': 'Payment Tier', 'EducationLevel': 'Education Level'},
                          title='Average and Median Payment Tier by Education Level',
                          barmode='group')
        )
    ], style={'width': '50%', 'display': 'inline-block', 'padding': '0 20'}),

], style={'fontFamily': 'Arial, sans-serif'})

if __name__ == '__main__':
    app.run_server(debug=True)



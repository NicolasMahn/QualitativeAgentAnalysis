import pickle 
import os
os.makedirs('output', exist_ok=True)



import pandas as pd
import numpy as np
import plotly.express as px
from dash import Dash, dcc, html, Input, Output, callback
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

# Load dataset
df = pd.read_csv('uploads/Employee.csv')

# Data preprocessing
# Map 'LeaveOrNot' to 'Leave' (0,1)
df['LeaveOrNot'] = df['LeaveOrNot'].astype(int)

# Encode categorical variables
le_gender = LabelEncoder()
df['Gender_enc'] = le_gender.fit_transform(df['Gender'])

le_ever_benched = LabelEncoder()
df['EverBenched_enc'] = le_ever_benched.fit_transform(df['EverBenched'])

le_city = LabelEncoder()
df['City_enc'] = le_city.fit_transform(df['City'])

# Simplify Education levels for input and modelling if needed (keeping as is for now)

# Select features for correlation and model
features = ['Age', 'PaymentTier', 'ExperienceInCurrentDomain', 'EverBenched_enc', 'Gender_enc']
X = df[features]
y = df['LeaveOrNot']

# Correlation with LeaveOrNot
corrs = df[features + ['LeaveOrNot']].corr()['LeaveOrNot'].drop('LeaveOrNot')

# Visualize correlations that are significant (absolute corr > 0.05)
significant_features = corrs[abs(corrs) > 0.05].index.tolist()

fig_corr = px.bar(
    x=corrs.loc[significant_features].index,
    y=corrs.loc[significant_features].values,
    labels={'x': 'Features', 'y': 'Correlation with Leave or Not'},
    title='Correlation between Features and Employee Attrition'
)

# Split data for modeling
X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, random_state=42, test_size=0.3)

# Build logistic regression model
model = LogisticRegression()
model.fit(X_train, y_train)

# Build the dash app
app = Dash(__name__)

app.layout = html.Div([
    html.H1('Employee Attrition Analysis & Prediction', style={'textAlign': 'center'}),

    # Correlation bar plot
    html.Div([
        dcc.Graph(figure=fig_corr)
    ], style={'width': '50%', 'display': 'inline-block', 'padding': '20px'}),

    # Model Prediction Interface
    html.Div([
        html.H3('Predict Attrition Probability'),
        html.Label('Age'),
        dcc.Input(id='input-age', type='number', value=30, min=18, max=100, step=1),

        html.Br(), html.Br(),
        html.Label('City'),
        dcc.Dropdown(
            id='input-city',
            options=[{'label': c, 'value': idx} for idx, c in enumerate(le_city.classes_)],
            value=0
        ),

        html.Br(),
        html.Label('Payment Tier'),
        dcc.Dropdown(
            id='input-paying-tier',
            options=[{'label': str(i), 'value': i} for i in sorted(df['PaymentTier'].unique())],
            value=1
        ),

        html.Br(),
        html.Label('Gender'),
        dcc.RadioItems(
            id='input-gender',
            options=[{'label': g, 'value': idx} for idx, g in enumerate(le_gender.classes_)],
            value=0,
            labelStyle={'display': 'inline-block', 'margin-right': '10px'}
        ),

        html.Br(),
        html.Label('Ever Benched'),
        dcc.RadioItems(
            id='input-ever-benched',
            options=[{'label': eb, 'value': idx} for idx, eb in enumerate(le_ever_benched.classes_)],
            value=0,
            labelStyle={'display': 'inline-block', 'margin-right': '10px'}
        ),

        html.Br(),
        html.Label('Experience in Current Domain (years)'),
        dcc.Input(id='input-experience', type='number', value=2, min=0, max=50, step=1),

        html.Br(), html.Br(),
        html.Label('Joining Year'),
        dcc.Input(id='input-joining-year', type='number', value=2017, min=1990, max=2025, step=1),

        html.Br(),
        html.Label('Education'),
        dcc.Dropdown(
            id='input-education',
            options=[{'label': edu, 'value': edu} for edu in sorted(df['Education'].unique())],
            value=df['Education'].unique()[0]
        ),

        html.Br(), html.Br(),
        html.Button('Predict Attrition Probability', id='predict-button'),
        html.Br(), html.Br(),
        html.Div(id='prediction-output', style={'fontSize': 20, 'color': 'darkblue'})
    ], style={'width': '40%', 'display': 'inline-block', 'verticalAlign': 'top', 'padding': '20px'})
])

@app.callback(
    Output('prediction-output', 'children'),
    Input('predict-button', 'n_clicks'),
    [
        Input('input-age', 'value'),
        Input('input-city', 'value'),
        Input('input-paying-tier', 'value'),
        Input('input-gender', 'value'),
        Input('input-ever-benched', 'value'),
        Input('input-experience', 'value'),
        Input('input-joining-year', 'value'),
        Input('input-education', 'value')
    ]
)
def predict_attrition(n_clicks, age, city, pay_tier, gender, ever_benched, experience, joining_year, education):
    if n_clicks is None:
        return ""
    # Prepare input vector for model
    # Use only model features: 'Age', 'PaymentTier', 'ExperienceInCurrentDomain', 'EverBenched_enc', 'Gender_enc'
    # For features not in model (city, joining_year, education), can ignore or extend model - here we ignore.
    input_df = pd.DataFrame([{
        'Age': age,
        'PaymentTier': pay_tier,
        'ExperienceInCurrentDomain': experience,
        'EverBenched_enc': ever_benched,
        'Gender_enc': gender
    }])
    proba = model.predict_proba(input_df)[0][1]
    return f'Predicted Probability of Leaving: {proba:.2%}'

if __name__ == '__main__':
    app.run_server(debug=True)



import pickle 
import os
os.makedirs('output', exist_ok=True)



import pandas as pd
import plotly.express as px
from dash import Dash, html, dcc

# Load dataset
df = pd.read_csv('uploads/Employee.csv')

# Compute overall gender distribution
gender_counts = df['Gender'].value_counts().reset_index()
gender_counts.columns = ['Gender', 'Count']

# Compute gender distribution by city
city_gender_counts = df.groupby(['City', 'Gender']).size().reset_index(name='Count')

# Create pie chart for overall gender distribution
fig_pie = px.pie(gender_counts, names='Gender', values='Count',
                 title='Overall Gender Distribution in Workforce',
                 color_discrete_sequence=px.colors.qualitative.Set2)

# Create grouped bar chart for gender distribution by city
fig_bar = px.bar(city_gender_counts, x='City', y='Count', color='Gender',
                 title='Gender Distribution by City',
                 barmode='group',
                 category_orders={"Gender": sorted(df['Gender'].unique())},
                 color_discrete_sequence=px.colors.qualitative.Set2)

# Initialize Dash app
app = Dash(__name__)

# Define layout
app.layout = html.Div([
    html.H1('Employee Gender Distribution Dashboard', style={'textAlign': 'center'}),
    html.Div([
        html.Div([
            dcc.Graph(figure=fig_pie)
        ], style={'width': '48%', 'display': 'inline-block', 'verticalAlign': 'top'}),
        html.Div([
            dcc.Graph(figure=fig_bar)
        ], style={'width': '48%', 'display': 'inline-block', 'verticalAlign': 'top'})
    ])
])

if __name__ == '__main__':
    app.run_server(debug=True)



import pickle 
import os
os.makedirs('output', exist_ok=True)



import pandas as pd
import numpy as np
import plotly.express as px
from dash import Dash, html, dcc
from dash.dependencies import Input, Output
from sklearn.linear_model import LinearRegression

# Load dataset
df = pd.read_csv('uploads/Employee.csv')

# Function to categorize Education level
def categorize_education(edu):
    edu = str(edu).lower()
    if 'phd' in edu or 'doctorate' in edu:
        return 'PhD'
    elif 'master' in edu:
        return 'Masters'
    elif 'bachelor' in edu:
        return 'Bachelors'
    else:
        return 'Others'

df['EducationLevel'] = df['Education'].apply(categorize_education)
edu_order = ['Others', 'Bachelors', 'Masters', 'PhD']
df['EducationLevel'] = pd.Categorical(df['EducationLevel'], categories=edu_order, ordered=True)

# Bin Experience in Current Domain for visualization
bins = [-1, 0, 2, 5, 10, 20, 50]
labels = ['0', '1-2', '3-5', '6-10', '11-20', '21+']
df['ExperienceBin'] = pd.cut(df['ExperienceInCurrentDomain'], bins=bins, labels=labels)

# Drop rows with missing values in key columns
df = df.dropna(subset=['PaymentTier', 'EducationLevel', 'ExperienceInCurrentDomain'])

# Encode EducationLevel for regression
df['Edu_Num'] = df['EducationLevel'].cat.codes  # 'Others' = 0, etc.

# Prepare regression variables
X = df[['Edu_Num', 'ExperienceInCurrentDomain']]
y = df['PaymentTier'].values

# Fit multiple linear regression model: PaymentTier ~ EducationLevel + Experience
reg = LinearRegression()
reg.fit(X, y)
y_pred = reg.predict(X)

# Calculate adjusted PaymentTier: residuals after controlling for Experience
# Center residuals by adding mean of PaymentTier so scale is comparable
df['PaymentTier_Adj'] = y - (y_pred - y.mean())

# Figure 1: Payment Tier vs Experience binned (box plot)
fig_exp = px.box(
    df,
    x='ExperienceBin',
    y='PaymentTier',
    category_orders={'ExperienceBin': labels},
    labels={'ExperienceBin': 'Experience in Current Domain (years)', 'PaymentTier': 'Payment Tier'},
    title='Payment Tier by Experience in Current Domain (Binned)'
)

# Figure 2: Payment Tier by EducationLevel (Unadjusted)
fig_edu_unadj = px.box(
    df,
    x='EducationLevel',
    y='PaymentTier',
    category_orders={'EducationLevel': edu_order},
    labels={'EducationLevel': 'Education Level', 'PaymentTier': 'Payment Tier'},
    title='Payment Tier by Education Level (Unadjusted)'
)

# Figure 3: Payment Tier by EducationLevel (Adjusted for Experience)
fig_edu_adj = px.box(
    df,
    x='EducationLevel',
    y='PaymentTier_Adj',
    category_orders={'EducationLevel': edu_order},
    labels={'EducationLevel': 'Education Level', 'PaymentTier_Adj': 'Adjusted Payment Tier (Residuals)'},
    title='Payment Tier by Education Level (Adjusted for Experience)'
)

# Prepare regression summary string
regression_summary = f"""
Multiple Linear Regression Results:
------------------------------------------------------
Coefficient for Education Level (numeric code): {reg.coef_[0]:.4f}
Coefficient for Experience in Current Domain: {reg.coef_[1]:.4f}
Intercept: {reg.intercept_:.4f}
"""

# Initialize Dash app
app = Dash(__name__)

app.layout = html.Div([
    html.H1("Employee Payment Tier Analysis", style={'textAlign': 'center', 'marginBottom': '20px'}),

    html.Div([
        html.H3("1. Experience in Current Domain vs Payment Tier"),
        dcc.Graph(figure=fig_exp)
    ], style={'width': '30%', 'display': 'inline-block', 'verticalAlign': 'top', 'padding': '10px'}),

    html.Div([
        html.H3("2a. Education vs Payment Tier (Unadjusted)"),
        dcc.Graph(figure=fig_edu_unadj)
    ], style={'width': '30%', 'display': 'inline-block', 'verticalAlign': 'top', 'padding': '10px'}),

    html.Div([
        html.H3("2b. Education vs Payment Tier (Adjusted for Experience)"),
        dcc.Graph(figure=fig_edu_adj)
    ], style={'width': '30%', 'display': 'inline-block', 'verticalAlign': 'top', 'padding': '10px'}),

    html.Div([
        html.H4("Regression Summary"),
        html.Pre(regression_summary, style={
            'fontFamily': 'monospace',
            'backgroundColor': '#f4f4f4',
            'padding': '10px',
            'border': '1px solid #ccc',
            'borderRadius': '5px',
            'maxWidth': '95%',
            'margin': '30px auto'
        })
    ], style={'width': '95%', 'margin': 'auto'}),
], style={'fontFamily': 'Arial, sans-serif', 'maxWidth': '1200px', 'margin': 'auto'})


if __name__ == '__main__':
    app.run_server(debug=True)



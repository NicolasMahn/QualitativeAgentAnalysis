import pickle 
import os
os.makedirs('output', exist_ok=True)



import pandas as pd
import numpy as np
import plotly.express as px
from dash import Dash, dcc, html, Input, Output
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

# Load dataset
df = pd.read_csv('uploads/Employee.csv')

# Encode categorical variables
le_gender = LabelEncoder()
df['Gender_enc'] = le_gender.fit_transform(df['Gender'])

le_ever_benched = LabelEncoder()
df['EverBenched_enc'] = le_ever_benched.fit_transform(df['EverBenched'])

le_city = LabelEncoder()
df['City_enc'] = le_city.fit_transform(df['City'])

# Features and target for model
features = ['Age', 'PaymentTier', 'ExperienceInCurrentDomain', 'EverBenched_enc', 'Gender_enc']
X = df[features]
y = df['LeaveOrNot'].astype(int)

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, random_state=42, test_size=0.3)

# Build logistic regression model
model = LogisticRegression()
model.fit(X_train, y_train)

# Compute global feature importance from model coefficients (absolute values)
importance_vals = np.abs(model.coef_[0])
importance_df = pd.DataFrame({
    'Feature': features,
    'Importance': importance_vals
}).sort_values(by='Importance', ascending=False)

# Create bar chart for global feature importance
fig_feature_imp = px.bar(
    importance_df,
    x='Feature',
    y='Importance',
    title='Global Feature Importance (Absolute Coefficients)',
    labels={'Importance': 'Absolute Coefficient', 'Feature': 'Feature'},
    text=importance_df['Importance'].round(3),
)

fig_feature_imp.update_traces(textposition='outside')

# Initialize Dash app
app = Dash(__name__)

# Layout
app.layout = html.Div([
    html.H1('Employee Attrition Analysis & Prediction', style={'textAlign': 'center'}),

    html.Div([
        dcc.Graph(
            id='fig-corr',
            figure=px.bar(
                x=df[features + ['LeaveOrNot']].corr()['LeaveOrNot'].drop('LeaveOrNot').index,
                y=df[features + ['LeaveOrNot']].corr()['LeaveOrNot'].drop('LeaveOrNot').values,
                labels={'x': 'Features', 'y': 'Correlation with Leave or Not'},
                title='Correlation between Features and Employee Attrition'
            )
        )
    ], style={'width': '45%', 'display': 'inline-block', 'verticalAlign': 'top', 'padding': '20px'}),

    html.Div([
        html.H3('Predict Attrition Probability'),
        html.Label('Age'),
        dcc.Input(id='input-age', type='number', value=30, min=18, max=100, step=1),

        html.Br(), html.Br(),
        html.Label('City'),
        dcc.Dropdown(
            id='input-city',
            options=[{'label': c, 'value': idx} for idx, c in enumerate(le_city.classes_)],
            value=0
        ),

        html.Br(),
        html.Label('Payment Tier'),
        dcc.Dropdown(
            id='input-paying-tier',
            options=[{'label': str(i), 'value': i} for i in sorted(df['PaymentTier'].unique())],
            value=1
        ),

        html.Br(),
        html.Label('Gender'),
        dcc.RadioItems(
            id='input-gender',
            options=[{'label': g, 'value': idx} for idx, g in enumerate(le_gender.classes_)],
            value=0,
            labelStyle={'display': 'inline-block', 'margin-right': '10px'}
        ),

        html.Br(),
        html.Label('Ever Benched'),
        dcc.RadioItems(
            id='input-ever-benched',
            options=[{'label': eb, 'value': idx} for idx, eb in enumerate(le_ever_benched.classes_)],
            value=0,
            labelStyle={'display': 'inline-block', 'margin-right': '10px'}
        ),

        html.Br(),
        html.Label('Experience in Current Domain (years)'),
        dcc.Input(id='input-experience', type='number', value=2, min=0, max=50, step=1),

        html.Br(), html.Br(),
        html.Button('Predict Attrition Probability', id='predict-button'),
        html.Br(), html.Br(),
        html.Div(id='prediction-output', style={'fontSize': 20, 'color': 'darkblue'}),

        html.Br(), html.Br(),
        html.H4('Model Global Feature Importance'),
        dcc.Graph(figure=fig_feature_imp),
    ], style={'width': '50%', 'display': 'inline-block', 'verticalAlign': 'top', 'padding': '20px'}),
])

# Callback for prediction
@app.callback(
    Output('prediction-output', 'children'),
    Input('predict-button', 'n_clicks'),
    [
        Input('input-age', 'value'),
        Input('input-paying-tier', 'value'),
        Input('input-experience', 'value'),
        Input('input-ever-benched', 'value'),
        Input('input-gender', 'value')
    ]
)
def predict_attrition(n_clicks, age, pay_tier, experience, ever_benched, gender):
    if n_clicks is None or any(v is None for v in [age, pay_tier, experience, ever_benched, gender]):
        return ""
    input_df = pd.DataFrame([{
        'Age': age,
        'PaymentTier': pay_tier,
        'ExperienceInCurrentDomain': experience,
        'EverBenched_enc': ever_benched,
        'Gender_enc': gender
    }])
    proba = model.predict_proba(input_df)[0][1]
    return f'Predicted Probability of Leaving: {proba:.2%}'

if __name__ == '__main__':
    app.run_server(debug=True)



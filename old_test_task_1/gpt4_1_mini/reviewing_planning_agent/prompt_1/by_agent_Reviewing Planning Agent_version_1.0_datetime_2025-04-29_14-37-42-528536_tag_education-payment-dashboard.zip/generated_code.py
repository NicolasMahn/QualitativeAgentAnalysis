import pickle 
import os
os.makedirs('output', exist_ok=True)



import pandas as pd
import plotly.express as px
from dash import Dash, html, dcc, Input, Output

# Load the dataset
df = pd.read_csv("uploads/Employee.csv")

# Define education level categorization
education_map = {
    'Bachelors': 'Bachelors',
    'Masters': 'Masters',
    'PhD': 'PhD',
    'Bachelor': 'Bachelors',
    'Master': 'Masters',
    'MSc': 'Masters',
    'MBA': 'Masters'
}

def categorize_education(x):
    for key in education_map:
        if key.lower() in str(x).lower():
            return education_map[key]
    return 'Others'

df['Education_Level'] = df['Education'].apply(categorize_education)

# Compute average payment tier per education level
mean_payment = df.groupby('Education_Level')['PaymentTier'].mean().reset_index()

# Initialize the Dash app
app = Dash(__name__)
app.title = "Employee Education vs Payment Tier Analysis"

app.layout = html.Div([
    html.H1("Employee Education vs Payment Tier Analysis"),
    html.P("Visualize the relationship between employee education levels and payment tiers."),
    dcc.RadioItems(
        id="chart-type",
        options=[
            {"label": "Box Plot (Payment Tier Distribution)", "value": "box"},
            {"label": "Bar Chart (Average Payment Tier)", "value": "bar"}
        ],
        value="box",
        labelStyle={'display': 'inline-block', 'margin-right': '20px'}
    ),
    dcc.Graph(id="education-payment-graph"),
    # Optional: Div for any additional info or tooltips
    html.Div(id='tooltip-info', style={'marginTop': 20})
])

@app.callback(
    Output("education-payment-graph", "figure"),
    Input("chart-type", "value")
)
def update_graph(chart_type):
    category_order = ['Bachelors', 'Masters', 'PhD', 'Others']
    if chart_type == "box":
        fig = px.box(df, x="Education_Level", y="PaymentTier",
                     category_orders={"Education_Level": category_order},
                     points="all",
                     title="Payment Tier Distribution by Education Level",
                     labels={"Education_Level": "Education Level", "PaymentTier": "Payment Tier"})
    else:
        fig = px.bar(mean_payment, x="Education_Level", y="PaymentTier",
                     category_orders={"Education_Level": category_order},
                     title="Average Payment Tier by Education Level",
                     labels={"Education_Level": "Education Level", "PaymentTier": "Average Payment Tier"})
    fig.update_layout(template='plotly_white')
    return fig

if __name__ == "__main__":
    app.run_server(debug=True)



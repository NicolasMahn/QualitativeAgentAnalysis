import pickle 
import os
os.makedirs('output', exist_ok=True)



import pandas as pd
import plotly.express as px
from dash import Dash, html, dcc

# Load dataset
df = pd.read_csv('uploads/Employee.csv')

# 1. Overall gender distribution within the workforce
gender_counts = df['Gender'].value_counts().reset_index()
gender_counts.columns = ['Gender', 'Count']

# 2. Gender distribution across different cities
# Calculate counts of gender per City
city_gender_counts = df.groupby(['City', 'Gender']).size().reset_index(name='Count')

# 3. Create Dash app with visualizations
app = Dash(__name__)

app.layout = html.Div([
    html.H1("Dashboard: Gender Distribution in Workforce", style={'textAlign': 'center'}),
    
    html.Div([
        html.H2("Overall Gender Distribution"),
        dcc.Graph(
            id='gender-pie-chart',
            figure=px.pie(
                gender_counts,
                names='Gender',
                values='Count',
                title='Overall Gender Distribution',
                color='Gender',
                color_discrete_map={'Male':'blue','Female':'pink','Other': 'green'}
            )
        )
    ], style={'width': '48%', 'display': 'inline-block', 'verticalAlign': 'top'}),
    
    html.Div([
        html.H2("Gender Distribution by City"),
        dcc.Graph(
            id='city-gender-bar-chart',
            figure=px.bar(
                city_gender_counts,
                x='City',
                y='Count',
                color='Gender',
                barmode='group',
                title='Gender Distribution Across Cities',
                labels={'Count': 'Number of Employees', 'City': 'City'},
                color_discrete_map={'Male':'blue','Female':'pink','Other':'green'}
            )
        )
    ], style={'width': '48%', 'display': 'inline-block', 'verticalAlign': 'top', 'marginLeft': '4%'})
])



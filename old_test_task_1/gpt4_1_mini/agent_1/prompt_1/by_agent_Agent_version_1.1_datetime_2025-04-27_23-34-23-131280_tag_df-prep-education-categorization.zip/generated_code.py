import pickle 
import os
os.makedirs('output', exist_ok=True)



import pandas as pd
from dash import Dash, html, dcc, Input, Output
import plotly.express as px

# Load dataset
df = pd.read_csv('uploads/Employee.csv')

# Map Education to three levels: 'Bachelors', 'Masters', 'PhD', others as 'Others'
def map_education_level(val):
    val_lower = val.lower()
    if 'phd' in val_lower:
        return 'PhD'
    elif 'master' in val_lower:
        return 'Masters'
    elif 'bachelor' in val_lower:
        return 'Bachelors'
    else:
        return 'Others'

df['Education_Level'] = df['Education'].apply(map_education_level)

# For visualization, convert PaymentTier to categorical for better display
df['PaymentTier_cat'] = df['PaymentTier'].astype(str)

# Initialize Dash app
app = Dash(__name__)

app.layout = html.Div([
    html.H1("Employee Education vs Payment Tier Analysis", style={'textAlign': 'center'}),
    
    dcc.RadioItems(
        id='plot-type',
        options=[
            {'label': 'Box Plot: Payment Tier distribution per Education Level', 'value': 'box'},
            {'label': 'Bar Chart: Average Payment Tier per Education Level', 'value': 'bar'}
        ],
        value='box',
        labelStyle={'display': 'inline-block', 'margin-right': '20px'}
    ),
    
    dcc.Graph(id='education-payment-graph')
])

@app.callback(
    Output('education-payment-graph', 'figure'),
    Input('plot-type', 'value')
)
def update_graph(plot_type):
    if plot_type == 'box':
        # Box plot showing distribution of Payment Tiers per Education Level
        fig = px.box(df, x='Education_Level', y='PaymentTier', 
                     category_orders={'Education_Level': ['Bachelors', 'Masters', 'PhD', 'Others']},
                     points="all",
                     labels={'PaymentTier': 'Payment Tier', 'Education_Level': 'Education Level'},
                     title='Distribution of Payment Tier by Education Level')
    else:
        # Bar chart showing average Payment Tier per Education Level
        avg_payment = df.groupby('Education_Level')['PaymentTier'].mean().reset_index()
        avg_payment['Education_Level'] = pd.Categorical(
            avg_payment['Education_Level'],
            categories=['Bachelors', 'Masters', 'PhD', 'Others'],
            ordered=True
        )
        avg_payment = avg_payment.sort_values('Education_Level')
        fig = px.bar(avg_payment, x='Education_Level', y='PaymentTier',
                     labels={'PaymentTier': 'Average Payment Tier', 'Education_Level': 'Education Level'},
                     title='Average Payment Tier by Education Level')
    
    fig.update_layout(template='plotly_white')
    return fig


